import SpeedReaderAI from "./components/SpeedReaderAI";

function App() {
  return (
    <div className="App">
      <h1 className="text-3xl font-bold text-center my-4">AI Speed Reader</h1>
      <SpeedReaderAI />
    </div>
  );
}

export default App;
