export default function ComprehensionTest({ comprehension }) {
    return (
      <div className="mt-6 p-4 border border-gray-300 rounded-md w-full max-w-lg">
        <h3 className="text-lg font-semibold">Comprehension Test</h3>
        <p>{comprehension || "Click the button to generate a question."}</p>
      </div>
    );
  }
  