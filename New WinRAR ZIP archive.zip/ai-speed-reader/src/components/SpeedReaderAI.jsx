import { useState } from "react";
import TextInput from "./TextInput";
import SpeedControls from "./SpeedControls";
import ComprehensionTest from "./ComprehensionTest";
import { useSpeechSynthesis } from "react-speech-kit";

export default function SpeedReaderAI() {
  const [text, setText] = useState("");
  const [words, setWords] = useState([]);
  const [index, setIndex] = useState(0);
  const [speed, setSpeed] = useState(300);
  const [running, setRunning] = useState(false);
  const [comprehension, setComprehension] = useState("");
  const { speak, cancel } = useSpeechSynthesis();

  const startReading = () => {
    setWords(text.split(" "));
    setIndex(0);
    setRunning(true);

    const interval = setInterval(() => {
      setIndex((prevIndex) => {
        if (prevIndex < words.length - 1) {
          speak({ text: words[prevIndex] });
          return prevIndex + 1;
        } else {
          clearInterval(interval);
          setRunning(false);
          return prevIndex;
        }
      });
    }, speed);

    if (!running) {
      setRunning(true);
    } else {
      setRunning(false);
      clearInterval(interval);
    }
  };

  const generateComprehensionTest = () => {
    const sampleQuestions = [
      "What is the main idea of the passage?",
      "Can you summarize the key points in one sentence?",
      "What was the most important detail mentioned?",
    ];
    setComprehension(sampleQuestions[Math.floor(Math.random() * sampleQuestions.length)]);
  };

  return (
    <div className="flex flex-col items-center p-6">
      <TextInput setText={setText} />
      <SpeedControls
        startReading={startReading}
        running={running}
        setRunning={setRunning}
        generateComprehensionTest={generateComprehensionTest}
        speed={speed}
        setSpeed={setSpeed}
      />
      <div className="mt-6 text-2xl font-bold h-12">{words[index] || ""}</div>
      <ComprehensionTest comprehension={comprehension} />
    </div>
  );
}
