export default function TextInput({ setText }) {
    return (
      <textarea
        className="w-full max-w-lg p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Paste or type your text here..."
        onChange={(e) => setText(e.target.value)}
      />
    );
  }
  