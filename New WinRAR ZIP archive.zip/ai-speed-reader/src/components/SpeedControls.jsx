export default function SpeedControls({ startReading, running, setRunning, generateComprehensionTest, speed, setSpeed }) {
    return (
      <div className="flex flex-col items-center mt-4">
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-700"
          onClick={startReading}
        >
          {running ? "Pause" : "Start Reading"}
        </button>
        <button
          className="mt-2 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-700"
          onClick={generateComprehensionTest}
        >
          Generate Comprehension Test
        </button>
        <label className="mt-4">Speed: {speed}ms</label>
        <input
          type="range"
          min="100"
          max="1000"
          step="50"
          value={speed}
          onChange={(e) => setSpeed(Number(e.target.value))}
          className="w-64"
        />
      </div>
    );
  }
  